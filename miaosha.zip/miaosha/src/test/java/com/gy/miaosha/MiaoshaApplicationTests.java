package com.gy.miaosha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiaoshaApplicationTests {

    @Test
    void contextLoads() {
    }

}
